var c = document.getElementById("can");
var ctx = c.getContext("2d");
ctx.fillstyle="#FF0000";
ctx.fillRect(75, 75, 50, 50);